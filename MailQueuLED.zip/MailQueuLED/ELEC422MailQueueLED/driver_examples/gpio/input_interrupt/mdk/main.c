#include "fsl_debug_console.h"
#include "fsl_port.h"
#include "fsl_gpio.h"
#include "fsl_common.h"
#include "fsl_adc16.h"
#include "board.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "string.h"
#include "stdio.h"
#include "cmsis_os.h"
#include "ELEC422.h"

/*******************************************************************************

 ******************************************************************************/
#define DEMO_ADC16_BASE ADC0
#define DEMO_ADC16_CHANNEL_GROUP 0U
#define DEMO_ADC16_USER_CHANNEL 12U
#define DEMO_ADC16_USER_CHANNEL2 13U



/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
const uint32_t g_Adc16_12bitFullRange = 4096U;

typedef struct {																//define the mail slot format
	char string[128];
} mail_format;

osMailQDef(mail_box, 16, mail_format);											//define the mailqueue
osMailQId  mail_box;															//create an ID
osThreadId   main_id, consumer_id, producer_id;
osThreadId sw2_id, sw3_id;
osThreadId led_id;
osThreadId adc1_id;
osThreadId adc2_id;

osMutexId adc_mutex;
osMutexDef(adc_mutex);


void BOARD_SW2_IRQ_HANDLER(void)
{
    /* Clear external interrupt flag. */
    GPIO_PortClearInterruptFlags(BOARD_SW2_GPIO, 1U << BOARD_SW2_GPIO_PIN);
	   osSignalSet(sw2_id, 0x01);
	   //LED_Toggle(1);
    /* Change state of button. */
}

void BOARD_SW3_IRQ_HANDLER(void)
{
    /* Clear external interrupt flag. */
		GPIO_PortClearInterruptFlags(BOARD_SW3_GPIO, 1U << BOARD_SW3_GPIO_PIN);
	osSignalSet(sw3_id, 0x01);
	   //LED_Toggle(0);
    /* Change state of button. */
}

void sw2_thread (void const *argument) 
{			
  uint32_t index;	
  mail_format *send_string;								//define a pointer in the mailslot format
  uint32_t length;	
	
  while(1)
	{
		      osSignalWait(0x00, osWaitForever);
	        send_string = (mail_format*)osMailAlloc(mail_box, osWaitForever);   //allocates a mailslot
          length = sprintf(send_string->string, "SW2 changed");
          osMailPut(mail_box, send_string);      //Post the mail to the mailbox
    			}
    }

		void sw3_thread (void const *argument) 
{			
  uint32_t index;	
  mail_format *send_string;								//define a pointer in the mailslot format
  uint32_t length;	
	
  while(1)
	{
		      osSignalWait(0x00, osWaitForever);
	        send_string = (mail_format*)osMailAlloc(mail_box, osWaitForever);   //allocates a mailslot
          length = sprintf(send_string->string, "SW3 changed");
          osMailPut(mail_box, send_string);      //Post the mail to the mailbox
    			}
    }

		void led_thread (void const *argument)
{
osEvent evt;
while (1)
{
evt = osSignalWait(0x00, osWaitForever);
if (evt.status == osEventSignal)
{
if (evt.value.signals == 0x01)
LED_On(0);
else if (evt.value.signals == 0x02)
LED_Off(0);
else if (evt.value.signals == 0x04)
LED_On(1);
else if (evt.value.signals == 0x08)
LED_Off(1);
else if (evt.value.signals == 0x10)
LED_On(2);
else if (evt.value.signals == 0x20)
LED_Off(2);
}
}
}

void adc1_thread (void const *argument) 
{			
	mail_format *send_string;								//define a pointer in the mailslot format
  uint32_t length;
	
	adc16_config_t adc16ConfigStruct;
    adc16_channel_config_t adc16ChannelConfigStruct;

  
  
    ADC16_GetDefaultConfig(&adc16ConfigStruct);
#ifdef BOARD_ADC_USE_ALT_VREF
    adc16ConfigStruct.referenceVoltageSource = kADC16_ReferenceVoltageSourceValt;
#endif
    ADC16_Init(DEMO_ADC16_BASE, &adc16ConfigStruct);
    ADC16_EnableHardwareTrigger(DEMO_ADC16_BASE, false); /* Make sure the software trigger is used. */
#if defined(FSL_FEATURE_ADC16_HAS_CALIBRATION) && FSL_FEATURE_ADC16_HAS_CALIBRATION
    if (kStatus_Success == ADC16_DoAutoCalibration(DEMO_ADC16_BASE))
    {
					send_string = (mail_format*)osMailAlloc(mail_box, osWaitForever);   //allocates a mailslot
          length = sprintf(send_string->string, "ADC16_DoAutoCalibration() Done\r\n");
          osMailPut(mail_box, send_string);      
			    PRINTF("ADC16_DoAutoCalibration() Done.\r\n");
    }
    else
    {
        send_string = (mail_format*)osMailAlloc(mail_box, osWaitForever);   //allocates a mailslot
        length = sprintf(send_string->string, "ADC16_DoAutoCalibration() Failed\r\n");
        osMailPut(mail_box, send_string);      
	    }
#endif /* FSL_FEATURE_ADC16_HAS_CALIBRATION */
     send_string = (mail_format*)osMailAlloc(mail_box, osWaitForever);   //allocates a mailslot
     length = sprintf(send_string->string, "ADC Full Range: %d\r\n");
     osMailPut(mail_box, send_string);      
    
    adc16ChannelConfigStruct.channelNumber                        = DEMO_ADC16_USER_CHANNEL;
    adc16ChannelConfigStruct.enableInterruptOnConversionCompleted = false;
#if defined(FSL_FEATURE_ADC16_HAS_DIFF_MODE) && FSL_FEATURE_ADC16_HAS_DIFF_MODE
    adc16ChannelConfigStruct.enableDifferentialConversion = false;
#endif /* FSL_FEATURE_ADC16_HAS_DIFF_MODE */

    while (1)
    {
         /*
         When in software trigger mode, each conversion would be launched once calling the "ADC16_ChannelConfigure()"
         function, which works like writing a conversion command and executing it. For another channel's conversion,
         just to change the "channelNumber" field in channel's configuration structure, and call the
         "ADC16_ChannelConfigure() again.
        */
			  osMutexWait(adc_mutex, osWaitForever);
			
        ADC16_SetChannelConfig(DEMO_ADC16_BASE, DEMO_ADC16_CHANNEL_GROUP, &adc16ChannelConfigStruct);
        while (0U == (kADC16_ChannelConversionDoneFlag &
                      ADC16_GetChannelStatusFlags(DEMO_ADC16_BASE, DEMO_ADC16_CHANNEL_GROUP)))
        {
        }
		     send_string = (mail_format*)osMailAlloc(mail_box, osWaitForever);   //allocates a mailslot
         length = sprintf(send_string->string, "ADC1 Value: %d\r\n", ADC16_GetChannelConversionValue(DEMO_ADC16_BASE, DEMO_ADC16_CHANNEL_GROUP));
        osMutexRelease(adc_mutex); 
				osMailPut(mail_box, send_string);
         osDelay(1000);
    }
}

void adc2_thread (void const *argument) 
{			
	mail_format *send_string;								//define a pointer in the mailslot format
  uint32_t length;
	
	adc16_config_t adc16ConfigStruct;
    adc16_channel_config_t adc16ChannelConfigStruct;

  
  
    ADC16_GetDefaultConfig(&adc16ConfigStruct);
#ifdef BOARD_ADC_USE_ALT_VREF
    adc16ConfigStruct.referenceVoltageSource = kADC16_ReferenceVoltageSourceValt;
#endif
    ADC16_Init(DEMO_ADC16_BASE, &adc16ConfigStruct);
    ADC16_EnableHardwareTrigger(DEMO_ADC16_BASE, false); /* Make sure the software trigger is used. */
#if defined(FSL_FEATURE_ADC16_HAS_CALIBRATION) && FSL_FEATURE_ADC16_HAS_CALIBRATION
    if (kStatus_Success == ADC16_DoAutoCalibration(DEMO_ADC16_BASE))
    {
					send_string = (mail_format*)osMailAlloc(mail_box, osWaitForever);   //allocates a mailslot
          length = sprintf(send_string->string, "ADC16_DoAutoCalibration() Done\r\n");
          osMailPut(mail_box, send_string);      
			    PRINTF("ADC16_DoAutoCalibration() Done.\r\n");
    }
    else
    {
        send_string = (mail_format*)osMailAlloc(mail_box, osWaitForever);   //allocates a mailslot
        length = sprintf(send_string->string, "ADC16_DoAutoCalibration() Failed\r\n");
        osMailPut(mail_box, send_string);      
	    }
#endif /* FSL_FEATURE_ADC16_HAS_CALIBRATION */
     send_string = (mail_format*)osMailAlloc(mail_box, osWaitForever);   //allocates a mailslot
     length = sprintf(send_string->string, "ADC Full Range: %d\r\n");
     osMailPut(mail_box, send_string);      
    
    adc16ChannelConfigStruct.channelNumber                        = DEMO_ADC16_USER_CHANNEL2;
    adc16ChannelConfigStruct.enableInterruptOnConversionCompleted = false;
#if defined(FSL_FEATURE_ADC16_HAS_DIFF_MODE) && FSL_FEATURE_ADC16_HAS_DIFF_MODE
    adc16ChannelConfigStruct.enableDifferentialConversion = false;
#endif /* FSL_FEATURE_ADC16_HAS_DIFF_MODE */

    while (1)
    {
			   osSignalWait(0x00, osWaitForever);
         /*
         When in software trigger mode, each conversion would be launched once calling the "ADC16_ChannelConfigure()"
         function, which works like writing a conversion command and executing it. For another channel's conversion,
         just to change the "channelNumber" field in channel's configuration structure, and call the
         "ADC16_ChannelConfigure() again.
        */
			  osMutexWait(adc_mutex, osWaitForever);
        ADC16_SetChannelConfig(DEMO_ADC16_BASE, DEMO_ADC16_CHANNEL_GROUP, &adc16ChannelConfigStruct);
        while (0U == (kADC16_ChannelConversionDoneFlag &
                      ADC16_GetChannelStatusFlags(DEMO_ADC16_BASE, DEMO_ADC16_CHANNEL_GROUP)))
        {
        }
		     send_string = (mail_format*)osMailAlloc(mail_box, osWaitForever);   //allocates a mailslot
         length = sprintf(send_string->string, "ADC2 Value: %d\r\n", ADC16_GetChannelConversionValue(DEMO_ADC16_BASE, DEMO_ADC16_CHANNEL_GROUP));
         osMutexRelease(adc_mutex);
				 osMailPut(mail_box, send_string);
         
    }
}
void LED_Producer (void const *argument) 
{			
  uint32_t index;	
  mail_format *send_string;								//define a pointer in the mailslot format
  uint32_t length;	
	char read_value;

  while(1)
	{
		      read_value = GETCHAR();
		      if (read_value == 'R')
					osSignalSet(led_id, 0x01);
					else if (read_value == 'r')
					osSignalSet(led_id, 0x02);
					else if (read_value == 'G')
					osSignalSet(led_id, 0x04);
					else if (read_value == 'g')
					osSignalSet(led_id, 0x08);
					else if (read_value == 'B')
					osSignalSet(led_id, 0x10);
					else if (read_value == 'b')
					osSignalSet(led_id, 0x20);
					else if (read_value == '2')
          osSignalSet(adc2_id, 0x01);
					
    		  send_string = (mail_format*)osMailAlloc(mail_box, osWaitForever);   //allocates a mailslot
          length = sprintf(send_string->string, "%c\n", read_value);
          osMailPut(mail_box, send_string);      //Post the mail to the mailbox
			}
    }

void LED_Consumer (void const *argument)
{
osEvent evt;                                                                    //declare an osEvent variable
mail_format *rec_string;                                                                //define a pointer in the mailslot format
   
    while (1)
    {
			  PRINTF("Started\n");
        evt = osMailGet(mail_box, osWaitForever);                                //wait until a message arrives
        if(evt.status == osEventMail)                                             //Check for a valid message
        {
            rec_string = (mail_format*)evt.value.p;
            PRINTF("%s", rec_string);
            osMailFree(mail_box, rec_string);                                    //Free the mailslot
        }
    }   
}

osThreadDef(LED_Producer, osPriorityNormal, 1,0);
osThreadDef(LED_Consumer, osPriorityNormal, 1,0);
osThreadDef(sw2_thread, osPriorityNormal, 1,0);
osThreadDef(sw3_thread, osPriorityNormal, 1,0);
osThreadDef(led_thread, osPriorityNormal, 1,0);
osThreadDef(adc1_thread, osPriorityNormal, 1,0);
osThreadDef(adc2_thread, osPriorityNormal, 1,0);

int main (void) 
{
	osKernelInitialize ();                    // initialize CMSIS-RTOS
	
	elec422_startup(); 
		
	mail_box = osMailCreate(osMailQ(mail_box), NULL);							// Create the mailbox
	adc_mutex = osMutexCreate(osMutex(adc_mutex)); // Create the Mutex

	
  producer_id = osThreadCreate(osThread(LED_Producer), NULL);
	consumer_id = osThreadCreate(osThread(LED_Consumer), NULL);
	sw2_id =  osThreadCreate(osThread(sw2_thread), NULL);
	sw3_id =  osThreadCreate(osThread(sw3_thread), NULL);
	led_id = osThreadCreate(osThread(led_thread), NULL);
	adc1_id = osThreadCreate(osThread(adc1_thread), NULL);
  adc2_id = osThreadCreate(osThread(adc2_thread), NULL);
	osKernelStart ();                         // start thread execution 
	main_id = osThreadGetId();
	osDelay(1000);
	osThreadTerminate(main_id);
	return(0);//will never get here 
	
}