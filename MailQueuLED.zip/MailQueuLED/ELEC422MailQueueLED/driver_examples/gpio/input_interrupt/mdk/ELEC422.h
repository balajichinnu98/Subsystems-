void elec422_startup(void);
void LED_On(int led);
void LED_Off(int led);
void LED_Toggle(int led);
void delay (int count);
